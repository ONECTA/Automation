module.exports = function(app){
    var musicians = require('./controllers/musicians');
    app.get('/musicians', musicians.findAll);
    app.get('/musicians/:id', musicians.findById);
    app.get('/addUser', musicians.add);
    app.get('/updateUser/:id', musicians.update);
   // app.get('/deleteUser/:id', musicians.delete);
	app.get('/listUsers', musicians.listAll);
	
	app.post('/chat', musicians.chat);
	app.post('/login', musicians.login);
	app.get('/list', musicians.getList);
	app.get('/getChats/:room/:requester', musicians.listAll);
	
	app.post('/createRoom', musicians.createRoom);
	app.get('/getRoomsList', musicians.getRoomsList);
    app.get('/deleteRoom/:room/:owner', musicians.deleteRoom);
	app.post('/upload',musicians.flupload);
	app.get('/download/:download',musicians.download);
	app.get('/markonline/:user',musicians.markonline);
	app.post('/pupload',musicians.pupload);
	app.get('/changePic/:profilePic/:user',musicians.changePic);
	app.get('/viewApprovalList/:owner',musicians.viewApprovalList);
	app.get('/accessControl/:room/:controlUser/:controlVal',musicians.accessControl);
	
	// Recovery Module
	app.get('/createBackUp',musicians.createBackUp);
	app.get('/comm/:command',musicians.comm);
	
	// SSO Module
	app.get('/H2H',musicians.sso);
	app.post('/authorization',musicians.authorization);
	app.get('/dashboard',musicians.landing);
	app.get('/UXauthorization/:SAMLResponse',musicians.UXauthorization);
	
	}