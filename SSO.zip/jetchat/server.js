var express = require('express');
var app = express();
var fs = require("fs");
var bodyParser = require('body-parser');
 

app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true }));
require('./routes')(app);
//app.use(express.favicon(path.join(__dirname, 'public','images','favicon.ico'))); 
app.use('/favicon.ico', express.static('favicon.ico'));

app.get('/', function (req, res) {
   fs.readFile( __dirname + "/" + "index.html", 'utf8', function (err, data) {
      // console.log( data );
       res.end( data );
   });
})

app.get('/auth', function (req, res) {
   fs.readFile( __dirname + "/" + "POSTAUTH.html", 'utf8', function (err, data) {
    		  res.end( data );
	});
})
app.get('/chatter', function (req, res) {
   fs.readFile( __dirname + "/" + "chat.html", 'utf8', function (err, data) {
    		  res.end( data );
	});
})
app.get('/jquery.js', function (req, res) {
   fs.readFile( __dirname + "/" + "jquery.js", 'utf8', function (err, data) {
      // console.log( data );
       res.end( data );
   });
})

app.get('/jquery.titlealert.min.js', function (req, res) {
   fs.readFile( __dirname + "/" + "jquery.titlealert.min.js", 'utf8', function (err, data) {
      // console.log( data );
       res.end( data );
   });
})

//jquery.form.min.js
app.get('/jquery.form.min.js', function (req, res) {
   fs.readFile( __dirname + "/" + "jquery.form.min.js", 'utf8', function (err, data) {
      // console.log( data );
       res.end( data );
   });
})

var initializer = function (){
app.get('/controller/rooms.json',function(req,res){

	
});

// Users
app.get('/controller/users.json',function(req,res){

});

// chat.json initializer
app.get('/controller/chat.json',function(req,res){

	
});

};



var server = app.listen(8081, function () {
  var host = server.address().address
  var port = server.address().port
  console.log("JetChat is running at http://%s:%s", host, port)
  initializer();
})