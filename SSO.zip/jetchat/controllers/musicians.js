var fs = require("fs");
var multer = require('multer');
var path = require('path');
var mime = require('mime');
var cmd=require('node-cmd');
var request = require('request'); // npm install request


//get request from UI
exports.sso = function(req,res)
{
	// This should internally call BFGUI ssoping url
	//res.writeHead(301, { "Location": "http://" + req.headers['host'] + '/authorization' });
   res.writeHead(301, { "Location": "http://" + req.headers['host'] + '/dashboard' });
  
   return res.end('Redirecting to authorization.....');
	
};
//	post function 
exports.authorization =function(req,res){
	var authResp = {};
	// This will internally invoke User Experience API GET:UXauthorization end point
	/* request({ url: req.headers['host'] +  '/UXauthorization' , headers: req.headers, body: req.body }, function(err, remoteResponse, remoteBody) {
        if (err) { return res.status(500).end('Error'); }
         res.writeHead(301, { "Location": "http://" + req.headers['host'] + '/dashboard' });
         res.end(remoteBody);
    });*/
	
	console.log(req.body.SAMLResponse);
request
  .get('http://' + req.headers['host'] +  '/UXauthorization/' + req.body.SAMLResponse)
  .on('response', function(response) {
    console.log(response.statusCode) // 200
	//console.log(response.body)
	response.on("data", function(UXResp) {
    console.log("BODY: " + UXResp);
	//authResp = chunk;
    authResp = JSON.parse(UXResp);
	
	if(authResp.isValid == "true"){
	res.writeHead(301, { "Location": "http://" + req.headers['host'] + '/dashboard',"Set-Cookie": "jwt-token=" + authResp['jwt-token'] + "; httponly" });
    res.end();
	}
	else{
	res.end('Unauthorized!!');	
	}
  });
    //console.log(response.headers['content-type']) // 'image/png'
	
  })
};
//GET HOMEPAGE AFTER Authorization
exports.landing = function(req,res){
	 var headers = JSON.stringify(req.headers);
	if(headers.indexOf('cookie') > -1){
		if(req.headers['cookie'].indexOf('jwt-token') > -1){
		res.end(req.headers['cookie'] + ' Home Page Content');
		}	
	}
	else{
	res.writeHead(301, { "Location": "http://" + req.headers['host'] + '/auth'});
    res.end();
	}
};
//	GET function HOSTED IN UX LEVEL
exports.UXauthorization =function(req,res){
	//console.log(req.params.SAMLResponse);
	//res.write(req.params.SAMLResponse + ' :Authorization Success!!');
	// This will internally invoke User Experience API authorization end point
	if(req.params.SAMLResponse.trim() == "ABCDEF"){
	//res.writeHead('200',{"Content-type" : "application/json"});
	res.send({ "isValid":"true" , "jwt-token":"12345"});
	}else{
	//res.writeHead('200',{"Content-type" : "application/json"});
	res.send({ "isValid":"false" });
	}
};


exports.comm = function(req,res){
var cmds =  req.params.command ;
var curl = 'C:\Program Files\cURL\bin\curl.exe -k "https://www.ibm.com/support/knowledgecenter/v1/search?query=' + cmds + '&lang=en" -H "Cookie: JSESSIONID=0004VEW2N5ByHoc8ByblHd2vU84:197ec072u:180soqavf; UnicaNIODID=RhfjoKALBi4-aQp0Qwp; BMAID=133a2975-b5cf-45b8-8ff6-c85c0ede8262; ipctrl=1; ccf-global-intercept="%"7B"%"22date"%"22"%"3A"%"201492594111646"%"2C"%"22type"%"22"%"3A"%"20"%"22medallia"%"22"%"2C"%"22id"%"22"%"3A"%"20"%"22web-exp"%"22"%"7D; IBM_W3SSO_ACCESS=; CoreID6=39275086898514920825417&ci=50200000|IBM_GlobalMarketing_52640000|IBM_GlobalMarketing_50200000|ESTKCS_50200000|devwrkscon_50200000|IBM_Systems; _pk_ref.5.b1f1="%"5B"%"22"%"22"%"2C"%"22"%"22"%"2C1494234545"%"2C"%"22https"%"3A"%"2F"%"2Fwww.google.co.uk"%"2F"%"22"%"5D; _pk_id.5.b1f1=1975de3a0aeae176.1492756188.4.1494234562.1494234545.; cvo_sid1=QKZVP7N7W4KK; cvo_tid1=B5wND3smegI|1492082542|1494234569|0; PD_STATEFUL_da1f998a-fd9d-11e5-baa8-a628a0b3ab03="%"2Fgateway; cmTPSet=Y; com.ibm.commerce.ubx.idsync.ubx_v2"%"2C1=com.ibm.commerce.ubx.idsync.ubx_v2"%"2C1; __asc=d2d2230015c1f400ded440041a1; __auc=d4fefaa815b858a7846dec8aee5; CMAVID=none; CoreM_State=8~-1~-1~-1~-1~3~3~5~3~3~7~7~|~~|~~|~~|~||||||~|~~|~~|~~|~~|~~|~~|~~|~; CoreM_State_Content=6~|~CAC0F96687BBD9F2~|~0; utag_main=v_id:015b670cbfc3001292b4acbaddd81106d006c0650093c$_sn:7$_ss:0$_st:1495174721736$dc_visit:4$ses_id:1495172910381"%"3Bexp-session$_pn:2"%"3Bexp-session$ttd_uuid:7196c582-ff8b-4164-b96a-eb49a178be8e"%"3Bexp-session; 50200000_clogin=l=1495172911&v=1&e=1495174721957" -H "Accept-Encoding: gzip, deflate, sdch" -H "Accept-Language: en-GB,en-US;q=0.8,en;q=0.6" -H "User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36" -H "Accept: application/json, text/javascript, */*; q=0.01" -H "Referer: https://www.ibm.com/support/knowledgecenter/search/?scope=SS3JSW_5.2.0" -H "X-Requested-With: XMLHttpRequest" -H "Connection: keep-alive" --compressed';
 cmd.get(curl ,
        function(err, data, stderr){
            if (!err) {
               console.log('Output :\n\n' + data);
			   res.end(data);
            } else {
               console.log('error', err)
			    res.end('error :\n\n' + err);
            }
 
        }
    );
	
	
 
 };



exports.download = function(req, res){
  var file = __dirname + '/../uploads/' + req.params.download;
  res.download(file); // Set disposition and send it.
};

var user = {
   "user4" : {
      "name" : "mohit",
      "password" : "password4",
      "profession" : "teacher",
      "id": 4
   },
   
   "user2" : {
      "name" : "ashutosh",
      "password" : "password4",
      "profession" : "scientist",
      "id": 2
   }
}
var getLength = function(obj) {
    var i = 0, key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)){
            i++;
        }
    }
    return i;
};

var getUserList = function(obj){
var i = 0, key;
var list = "<u><b>User List</b></u><table>";
var now = new Date().getTime();
Object.getOwnPropertyNames(obj).forEach(
  function (val, idx, array) {
    //console.log(val);
 i++;
var lastping = obj[val].lastping;
var ppic =  '/../download/' + obj[val].profilePic;
var diff = now - lastping;
//console.log(diff);
 if(i != 1 && diff <= 5000){
 list = list + "<tr><td><img class='profilePic' src='" + ppic + "' id='" + val + "'/></td><td><a>" + val + "</a></td></tr>";
 }
  }
 
); 
return list + "</table>";
};

var initializer = function(data){
var getLen = JSON.stringify(data).length;

		if(getLen == 0){
		 console.log('No users.json exists . Intializing users.json');
		 var usersjson = '{"user" : {"mobile":"" , "name":"" , "id":"","lastping":0,"profilePic":""}}';
		 fs.writeFile(__dirname + "users.json" , usersjson , 'utf8', function(err,data){
			 if (err){
			 console.log(err);
			 };
			 console.log("users.json Intialized");
			// res.end("users.json Intialized" );
		 });
		}
		else{
		 console.log("users.json ok");
		// res.end("users.json ok" );
		}
}

exports.createBackUp = function(req,res){
var strJSON = getFilesizeInBytes(__dirname + "/" + "rooms.json");
if(strJSON != 0) { 
fs.createReadStream(__dirname + "/rooms.json").pipe(fs.createWriteStream(__dirname + "/BackUp_rooms.json"));
}
else{
	console.log("Dirty Write for rooms.json detected. Now Recovering !! ");
	fs.createReadStream(__dirname + "/BackUp_rooms.json").pipe(fs.createWriteStream(__dirname + "/rooms.json"));
	
}

var strJSON = getFilesizeInBytes(__dirname + "/" + "chat.json");
if(strJSON != 0) { 
fs.createReadStream(__dirname + "/chat.json").pipe(fs.createWriteStream(__dirname + "/BackUp_chat.json"));
}
else{
	console.log("Dirty Write for CHAT.json detected. Now Recovering !! ");
	fs.createReadStream(__dirname + "/BackUp_chat.json").pipe(fs.createWriteStream(__dirname + "/chat.json"));
}

var strJSON = getFilesizeInBytes(__dirname + "/" + "users.json");
if(strJSON != 0) { 
fs.createReadStream(__dirname + "/users.json").pipe(fs.createWriteStream(__dirname + "/BackUp_users.json"));
}
else{
	console.log("Dirty Write for USERS.json detected. Now Recovering !! ");
	fs.createReadStream(__dirname + "/BackUp_users.json").pipe(fs.createWriteStream(__dirname + "/users.json"));
}
res.end("Data Backed up");

};

exports.markonline = function(req,res){

  // First read existing users.
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
      
try{  
 //console.log(data);
   data = JSON.parse( data );
 
 data[req.params.user].lastping = new Date().getTime();
 //console.log(data);
//       res.end( JSON.stringify(data));
        data = JSON.stringify(data);
        fs.writeFile(__dirname + "/" + "users.json", data , 'utf8', function(err,data){
            if (err){
                console.log(err);
            };
            res.end(data);
        });
}
 catch(errr){
 console.log('Recovered users.json from ' + errr);
 fs.createReadStream(__dirname + "/BackUp_users.json").pipe(fs.createWriteStream(__dirname + "/users.json"));
 fs.createReadStream(__dirname + "/BackUp_chat.json").pipe(fs.createWriteStream(__dirname + "/chat.json"));
 fs.createReadStream(__dirname + "/BackUp_rooms.json").pipe(fs.createWriteStream(__dirname + "/rooms.json"));
 res.end('Data recovered for users.json<script>javascript:history.go(0);</script>');
 }
   });
};

exports.changePic = function(req,res){

  // First read existing users.
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
        data = JSON.parse( data );
 data[req.params.user].profilePic = req.params.profilePic;
 //console.log(data);
//       res.end( JSON.stringify(data));
        data = JSON.stringify(data);
        fs.writeFile(__dirname + "/" + "users.json", data , 'utf8', function(err,data){
            if (err){
                console.log(err);
            };
            res.end(data);
        });
   });
};



exports.getList = function(req,res){
 
  // First read existing users.
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
      // console.log(data);
	try{   data = JSON.parse( data );}catch(errr){
   console.log('Recovered users.json from ' + errr);
 fs.createReadStream(__dirname + "/BackUp_users.json").pipe(fs.createWriteStream(__dirname + "/users.json"));
 fs.createReadStream(__dirname + "/BackUp_chat.json").pipe(fs.createWriteStream(__dirname + "/chat.json"));
 fs.createReadStream(__dirname + "/BackUp_rooms.json").pipe(fs.createWriteStream(__dirname + "/rooms.json"));
res.end('Data recovered for users.json<script>javascript:history.go(0);</script>');  
  }
       res.end(getUserList(data));
   });
   
   
};  
  
exports.login = function(req,res){
//console.log("Received Params" + req.body.name);
var user = {"user" : {"mobile":"" , "name":"" , "id":"","lastping":0,"profilePic":""}};
fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
        data = JSON.parse( data );
 var userCtr = getLength(data)  - 1;
 var profilePic = "Default.jpg";
 //console.log(JSON.stringify(data).indexOf(req.body.name));
 if(JSON.stringify(data).indexOf(req.body.name) > -1){
 
 profilePic = data[req.body.name].profilePic;
 }
 if(getLength(data) != "undefined"){
 console.log(" Number of Users:" + (userCtr + 1));
 
 user["user"].mobile = req.body.mobile;
 user["user"].name = req.body.name;
 user["user"].id   = userCtr + 1;
 user["user"].lastping = new Date().getTime();
 user["user"].profilePic = profilePic;
 data[req.body.name] = user["user"];
 // console.log( data );
 //res.end( JSON.stringify(data));
 data = JSON.stringify(data);
 fs.writeFile(__dirname + "/" + "users.json", data , 'utf8', function(err,data){
 if (err){
 console.log(err);
 };
 res.end(data);
 });
 }
   });
};

exports.findAll = function(req, res){
  res.send([{
    "id": 1,
    "name": "Max",
    "band": "Maximum Pain",
    "instrument": "guitar"
  }]);
};

exports.findById = function (req, res) {
   // First read existing users.
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
       users = JSON.parse( data );
       var user = users["user" + req.params.id] 
     //  console.log( user );
       res.end( JSON.stringify(user));
   });
};

exports.add = function (req, res) {
   // First read existing users.
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
        data = JSON.parse( data );
        data["user4"] = user["user4"];
       // console.log( data );
//       res.end( JSON.stringify(data));
        data = JSON.stringify(data);
        fs.writeFile(__dirname + "/" + "users.json", data , 'utf8', function(err,data){
            if (err){
                console.log(err);
            };
            res.end(data);
        });
   });
};
var chatCtr = 0;
exports.chat = function (req, res) {
var chat = { "A_B" : {"to":"","from":"","msg":"","room":"","attachments":""}};

   // First read existing users.
   fs.readFile( __dirname + "/" + "chat.json", 'utf8', function (err, data) {
        data = JSON.parse( data );
        chatCtr++;
 var d = new Date();
 var n = d.getTime();
 chat["A_B"].from = req.body.sender;
 chat["A_B"].to   = "JGroup";
 chat["A_B"].msg  = req.body.msg;
 chat["A_B"].room = req.body.room;
 chat["A_B"].attachments = req.body.attachments;
 data[req.body.sender + "_" + chatCtr + "_" + n] = chat["A_B"];
       // console.log( data );
//       res.end( JSON.stringify(data));
        data = JSON.stringify(data);
        fs.writeFile(__dirname + "/" + "chat.json", data , 'utf8', function(err,data){
            if (err){
                console.log(err);
            };
            res.end(data);
        });
   });
};

exports.update = function (req, res) {
   // First read existing users.
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
        data = JSON.parse( data );
 
     data["user" + req.params.id] = user["user2"];
 data["user" + req.params.id].id = 3;
        console.log( data );
//       res.end( JSON.stringify(data));
        data = JSON.stringify(data);
        fs.writeFile(__dirname + "/" + "users.json", data , 'utf8', function(err,data){
            if (err){
                console.log(err);
            };
            res.end(data);
        });
   });
};

exports.deleteRoom = function (req, res) {

   // First read existing users.
   fs.readFile( __dirname + "/" + "rooms.json", 'utf8', function (err, data) {
    try{   data = JSON.parse( data );}catch(errr){
   console.log('Recovered users.json from ' + errr);
 fs.createReadStream(__dirname + "/BackUp_users.json").pipe(fs.createWriteStream(__dirname + "/users.json"));
 fs.createReadStream(__dirname + "/BackUp_chat.json").pipe(fs.createWriteStream(__dirname + "/chat.json"));
 fs.createReadStream(__dirname + "/BackUp_rooms.json").pipe(fs.createWriteStream(__dirname + "/rooms.json"));
res.end('Data recovered for users.json<script>javascript:history.go(0);</script>');  
  }
    var createdBy = data[req.params.room].createdBy;
    if(createdBy == req.params.owner){
    delete data[req.params.room];
     data = JSON.stringify(data);
        fs.writeFile(__dirname + "/" + "rooms.json", data , 'utf8', function(err,data){
            if (err){
                console.log(err);
            };
			deleteChat(req.params.room,res);
         console.log(req.params.room + " deleted!!");
    res.end("OK " + req.params.room + " deleted successfully!!" );
        });
      
    }
    else{
    console.log(req.params.owner + " not authorized to delete!!" );
       res.end(req.params.owner + " not authorized to delete!!" );
    }
 
   });
};

// Delete Chats for deleted room 
function deleteChat(room,res) {

   // First read existing users.
 fs.readFile( __dirname + "/" + "chat.json", 'utf8', function (err, data) {
    try{
	data = JSON.parse( data );
	}
	catch(errr){
	console.log('Recovered users.json from ' + errr);
	fs.createReadStream(__dirname + "/BackUp_users.json").pipe(fs.createWriteStream(__dirname + "/users.json"));
	fs.createReadStream(__dirname + "/BackUp_chat.json").pipe(fs.createWriteStream(__dirname + "/chat.json"));
	fs.createReadStream(__dirname + "/BackUp_rooms.json").pipe(fs.createWriteStream(__dirname + "/rooms.json"));
	res.end('Data recovered for users.json<script>javascript:history.go(0);</script>');  
  }
  
var obj = data;
Object.getOwnPropertyNames(obj).forEach(
  function (val, idx, array) {
	var lastping = obj[val].lastping;
	if(obj[val].room == room){
	console.log('Deleting -> ' + val);
		delete obj[val];
		data = obj;
		}
  });
  data = JSON.stringify(data);
fs.writeFile(__dirname + "/" + "chat.json", data , 'utf8', function(err,data){
			if (err){
						console.log(err);
					};
		console.log("Chat for room " + room + "deleted!!");
		res.end("OK Chat for room " + room +  " deleted successfully!!" );
		});  

 });
}


exports.viewApprovalList = function(req,res){
var approveList = "<u><b>User Messages</b></u><br><br>";

 fs.readFile( __dirname + "/" + "rooms.json", 'utf8', function (err, data) {
    try{
	data = JSON.parse( data );
	}
  catch(errr){
   console.log('Recovered rooms.json from ' + errr);
 fs.createReadStream(__dirname + "/BackUp_users.json").pipe(fs.createWriteStream(__dirname + "/users.json"));
 fs.createReadStream(__dirname + "/BackUp_chat.json").pipe(fs.createWriteStream(__dirname + "/chat.json"));
 fs.createReadStream(__dirname + "/BackUp_rooms.json").pipe(fs.createWriteStream(__dirname + "/rooms.json"));
   res.end('Data recovered for rooms.json<script>javascript:history.go(0);</script>');
   }	
    var obj = data;
  Object.getOwnPropertyNames(obj).forEach(
   function (val, idx, array) {
 //console.log(val);
 var createdBy = obj[val].createdBy;
 if(createdBy == req.params.owner){
 //approveList = approveList + obj[val].pending;
 if(obj[val].pending.indexOf("~") > -1){
 var pendingUsers = obj[val].pending.split("~");
 for(var i=1;i < pendingUsers.length - 1;i++){
 if( pendingUsers[i] != ""){
approveList = approveList + '<br><br><b class="apprmsg">Request from ' + pendingUsers[i] + ' for room ' + val + ' </b>   <select class="Access"><option value="Dummy">Select Action</option><option value="' + pendingUsers[i] + ':' + val + ':A">Approve</option><option value="' + pendingUsers[i] + ':' + val + ':R">Reject</option></select>'; 
 }
 
 }
 }}
   }
  
 ); 
 res.end(approveList);
 });
 
};

var updateJSONData = function(room,controlUser,controlVal,res){

 // First read existing users.
   fs.readFile( __dirname + "/" + "rooms.json", 'utf8', function (err, data) {
        data = JSON.parse( data );
 //"accessList":"","rejected":"","pending":""
 if(controlVal == "A"){
  data[room].accessList =  data[room].accessList  + "~" + controlUser + "~";
  data[room].rejected = data[room].rejected.replace("~" + controlUser + "~","");
  data[room].pending = data[room].pending.replace("~" + controlUser + "~","");
  
 }
 else if(controlVal == "R"){
  data[room].rejected =  data[room].rejected  + "~" + controlUser + "~";
  data[room].pending = data[room].pending.replace("~" + controlUser + "~","");
 }
 else if(controlVal == "P"){
 data[room].pending =  data[room].pending  + "~" + controlUser + "~";
 }
 else{
 console.log(controlVal + 'controlVal recieved');
 }
 console.log( 'User:' +  controlUser + ' is having ' +  controlVal + ' access to room:' + room );
//       res.end( JSON.stringify(data));
        data = JSON.stringify(data);
        fs.writeFile(__dirname + "/" + "rooms.json" , data , 'utf8', function(err,data){
            if (err){
                console.log(err);
            };
            res.end(data);
        });
   });
};

exports.accessControl = function (req, res) {
//room,controlUser,controlVal
updateJSONData(req.params.room,req.params.controlUser,req.params.controlVal,res);
};

var verifyAccess = function(room,user){
//console.log('Verifying access for user:' + user + ' in room:' + room);
 var status = "Default";
 fs.readFile( __dirname + "/" + "rooms.json", 'utf8', function (err, data) {
       data = JSON.parse( data );
    var obj = data;
       Object.getOwnPropertyNames(obj).forEach(
   function (val, idx, array) {
   var usrstr = "~" + user + "~";
  //console.log('Comp:' + val + '==' + room + ':' + "obj[val].accessLevel:" + obj[val].accessLevel);
  if(val == room && obj[val].accessLevel == "Restricted"){
 if(obj[val].accessList.indexOf(usrstr) > -1){
 status = "O";//"ok";
 return status;
 }
 else if(obj[val].rejected.indexOf(usrstr) > -1){
 status = "R";//"rejected";
 return status;
 }
 else if(obj[val].pending.indexOf(usrstr) > -1){
 status = "P";//"pending";
 return status;
 }
 else{
 status = "N";//NOTSENT";
 return status;
 }
  }
  else if(val == room && obj[val].accessLevel == "Open"){
  status = "O";
    return status; 
  }
   }); 
    //res.end(getRoomList(data));
});

}
var readChats = function(obj,room,user,res){
var i = 0, key;
var list = "";
//var status = verifyAccess(room,user) ;
// Verifying access
//console.log('Verifying access for user:' + user + ' in room:' + room);
 var status = "Default";
 fs.readFile( __dirname + "/" + "rooms.json", 'utf8', function (err, data) {
   try{
	data = JSON.parse( data );
	}
  catch(errr){
   console.log('Recovered rooms.json for room,user ' + room + ',' + user + 'from ' + errr);
 fs.createReadStream(__dirname + "/BackUp_users.json").pipe(fs.createWriteStream(__dirname + "/users.json"));
 fs.createReadStream(__dirname + "/BackUp_chat.json").pipe(fs.createWriteStream(__dirname + "/chat.json"));
 fs.createReadStream(__dirname + "/BackUp_rooms.json").pipe(fs.createWriteStream(__dirname + "/rooms.json"));
   res.end('Data recovered for rooms.json<script>javascript:history.go(0);</script>');
   }
    var obj1 = data;
       Object.getOwnPropertyNames(obj1).forEach(
   function (val, idx, array) {
   var usrstr = "~" + user + "~";
 // console.log('Comp:' + val + '==' + room + ':' + "obj1[val].accessLevel:" + obj1[val].accessLevel);
  if(val == room && obj1[val].accessLevel == "Restricted"){
 if(obj1[val].accessList.indexOf(usrstr) > -1){
 status = "O";//"ok";
 Object.getOwnPropertyNames(obj).forEach(
   function (val, idx, array) {
 if(obj[val].room == room){
 //console.log(val + ' -> ' + obj[val].room + ' -> '  + obj[val].msg);
 if(obj[val].attachments != ""){
 // list = list + "<b>" + val.split("_")[0] + "</b> : " + "<input type='button' class='attachments' value='" + obj[val].attachments + "' /><br>";
 list = list + "<b>" + val.split("_")[0] + "</b> : " + "<a class='attachments' href='/../download/" + obj[val].attachments + "' >" + obj[val].attachments.split("~~")[1] +"</a><br>";
 }
 else{
 list = list + "<b>" + val.split("_")[0] + "</b> : " + obj[val].msg  + "<br>";
 }
 
 }
   });
 }
 else if(obj1[val].rejected.indexOf(usrstr) > -1){
 status = "R";//"rejected";
 list = "JetChat:<B> Your request for access has been declined by owner<b>";
 }
 else if(obj1[val].pending.indexOf(usrstr) > -1){
 status = "P";//"pending";
 list = "JetChat:<B> Your request for access is pending with owner<b>";
 }
 else{
 status = "N";//NOTSENT";
 list = "JetChat:<B> Send request for access to owner<b><br><input type='button' name='Request' id='Request' class='Request' value='Request' />";

 }
 
  }
  else if(val == room && obj1[val].accessLevel == "Open"){
  status = "O";
  Object.getOwnPropertyNames(obj).forEach(
   function (val, idx, array) {
 if(obj[val].room == room){
 //console.log(val + ' -> ' + obj[val].room + ' -> '  + obj[val].msg);
 if(obj[val].attachments != ""){
 // list = list + "<b>" + val.split("_")[0] + "</b> : " + "<input type='button' class='attachments' value='" + obj[val].attachments + "' /><br>";
 list = list + "<b>" + val.split("_")[0] + "</b> : " + "<a class='attachments' href='/../download/" + obj[val].attachments + "' >" + obj[val].attachments.split("~~")[1] +"</a><br>";
 }
 else{
 list = list + "<b>" + val.split("_")[0] + "</b> : " + obj[val].msg  + "<br>";
 }
 
 }
   });
  }
   }); 
    //res.end(getRoomList(data));
//console.log(status + "list" + list);
res.end(list);

});

// end of Verifying accessControl

};



exports.listAll=function (req, res) {
   fs.readFile( __dirname + "/" + "chat.json", 'utf8', function (err, data) {
      try{
	data = JSON.parse( data );
	}
  catch(errr){
   console.log('Recovered chat.json for req.params.room,req.params.requester ' + req.params.room + ',' + req.params.requester + 'from ' + errr);
 fs.createReadStream(__dirname + "/BackUp_users.json").pipe(fs.createWriteStream(__dirname + "/users.json"));
 fs.createReadStream(__dirname + "/BackUp_chat.json").pipe(fs.createWriteStream(__dirname + "/chat.json"));
 fs.createReadStream(__dirname + "/BackUp_rooms.json").pipe(fs.createWriteStream(__dirname + "/rooms.json"));
   res.end('Data recovered for rooms.json<script>javascript:history.go(0);</script>');
   }
       readChats(data,req.params.room,req.params.requester,res);
   });
};
function getFilesizeInBytes(filename) {
    const stats = fs.statSync(filename);
    const fileSizeInBytes = stats.size;
    return fileSizeInBytes;
}
exports.createRoom = function(req,res){
var room = {"RoomName" : {"createdBy":"" , "id":"","accessLevel":"","accessList":"","rejected":"","pending":""}};
fs.readFile( __dirname + "/" + "rooms.json", 'utf8', function (err, data) {
data = JSON.parse( data );
 var userCtr = getLength(data)  + 1;
 if(getLength(data) != "undefined"){
 console.log(" Number of Rooms:" + userCtr);
 room["RoomName"].createdBy   = req.body.createdBy;
 room["RoomName"].id         = userCtr + 1;
 room["RoomName"].accessLevel = req.body.accessLevel;
 room["RoomName"].accessList  = req.body.accessList;
 
 data[req.body.RoomName] = room["RoomName"];
 console.log( "Creating Room: " + req.body.RoomName );
 //res.end( JSON.stringify(data));
 data = JSON.stringify(data);
 fs.writeFile(__dirname + "/" + "rooms.json", data , 'utf8', function(err,data){
 if (err){
 console.log(err);
 };
 res.end("Room Created:" + req.body.RoomName);
 });
 }
   });
};

var getRoomList = function(obj){
var i = 0, key;
var list = '<option value="JetChat">Change Topic</option>';
Object.getOwnPropertyNames(obj).forEach(
  function (val, idx, array) {
   // console.log(val);
 i++;
 if(i != 1){
 list = list + '<option value="' + val + '">' + val + '</option>';
 }
  }
 
); 
return list;
};

exports.getRoomsList = function(req,res){
  // First read existing users.
   fs.readFile( __dirname + "/" + "rooms.json", 'utf8', function (err, data) {
      try{ data = JSON.parse( data );}
  catch(errr){
   console.log('Recovered rooms.json from ' + errr);
 fs.createReadStream(__dirname + "/BackUp_users.json").pipe(fs.createWriteStream(__dirname + "/users.json"));
 fs.createReadStream(__dirname + "/BackUp_chat.json").pipe(fs.createWriteStream(__dirname + "/chat.json"));
 fs.createReadStream(__dirname + "/BackUp_rooms.json").pipe(fs.createWriteStream(__dirname + "/rooms.json"));
res.end('Data recovered for rooms.json<script>javascript:history.go(0);</script>');  
  }
       res.end(getRoomList(data));
   });
};  

exports.flupload = function (req, res) { 
    upload(req, res, function (err) { 
        if (err) { 
            return res.end("Something went wrong!"); 
        } 
 
        return res.end("File uploaded sucessfully! :" + uploadedFile); 
    }); 
}; 
exports.pupload = function (req, res) { 
    picupload(req, res, function (err) { 
        if (err) { 
            return res.end("Something went wrong!" + err ); 
        } 
 
        return res.end("Profile Pic uploaded sucessfully! :" + uploadedFile); 
    }); 
}; 



var uploadedFile = "";

var Storage = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, "./uploads");
    },
    filename: function (req, file, callback) {
 uploadedFile = file.fieldname + "_" + Date.now() + "~~" + file.originalname;
        callback(null, uploadedFile);
    }
});

var upload = multer({ storage: Storage }).array("imgUploader", 3); //Field name and max count 

var picupload = multer({ storage: Storage }).array("Profile", 3); //Field name and max count 
