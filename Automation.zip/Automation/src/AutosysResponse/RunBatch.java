package AutosysResponse;

import java.io.IOException;
import java.lang.Runtime;
public class RunBatch {

	/**
	 * @param args
	 */
	public void runBat(String batchfile,String PathtoBatch){
		try {
			System.out.println(batchfile);
            String[] command = {"cmd.exe", "/C", "Start /min", PathtoBatch + batchfile};
            Process p =  Runtime.getRuntime().exec(command);
	         System.out.println(p.toString());
	        } catch (IOException ex) {
        }
	}
 
}
