package AutosysResponse;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/* ****************************************************************************************
Created  By  : Ashutosh Kumar Kushwaha
Creation Date: Friday September 16, 2016

Functionality
-------------
1. Batch file is triggering the jar that is reading a configuration file  having Start,End
   time,Job Name and Instances of all the jobs . 
2. Only the jobs which are qualifying the schedule as per current time will be triggered 
   and their status will be mailed to respective team for both success and fail scenario's .
3. A retry functionality will retry to rerun the automation in case of some failure till 
   the particular job's end time after which it will skip this job and switch to next one .
4. Job not found in Autosys
5. All possible status of Jobs including no or blank status
6. Time exceeded the permissible limit
7. Script not able to hit the URL and after few retries, it should return back(mail) the 
   exception to user with text that script is unable to reach the URL, so please perform 
   this check manually.
8. I will add a exception in AutoSys to check for permissible time for a job and in case 
   if it didn't meet, the user should be notified.
9. Any expected error then what we can list here needs to be catch/try and alerted to user.
********************************************************************************************
*/

public class VerifyResponse {

	private final String USER_AGENT = "Mozilla/5.0";

	public static void main(String[] args) throws Exception {

       
        if(System.getProperty("host") != null){
        VerifyResponse http = new VerifyResponse();
		http.getConfig();
        }
        else{
        	System.out.println("No host name present . Bot Mode Activated \n");
        	ResponseRobot bot = new ResponseRobot();
        	bot.runRobot();
        }
      }
	public String prepareURL(String JobName,String JobInstance){
		String finalUrl = "http://my.barcapint.com/ATS/cgi-bin/view.pl?job_name=" + JobName.replaceAll("%", "%25") + "&view_type=status&instance=" + JobInstance;
		return finalUrl;
	}
	
	public void getConfig(){
		try {
			File fXmlFile = new File("AutomationConfig.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			NodeList nList = doc.getElementsByTagName("Job");
			System.out.println("---------  FETCHIING Autosys Reports --------");

			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);

			//System.out.println("\n JOB NUMBER :" + nNode.getNodeName());
			System.out.println("\n ***********JOB NUMBER :" + (temp + 1) + "**************");

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;
					System.out.println("StartTime : " + eElement.getElementsByTagName("StartTime").item(0).getTextContent());
					System.out.println("EndTime : " + eElement.getElementsByTagName("EndTime").item(0).getTextContent());
					System.out.println("GreenFlag : " + eElement.getElementsByTagName("GreenFlag").item(0).getTextContent());
					
					String sJobName = eElement.getElementsByTagName("JobName").item(0).getTextContent();
					String sJobInstance = eElement.getElementsByTagName("JobInstance").item(0).getTextContent();
					String sGreenFlag = eElement.getElementsByTagName("GreenFlag").item(0).getTextContent();
					boolean check = validateTime(eElement.getElementsByTagName("StartTime").item(0).getTextContent(),eElement.getElementsByTagName("EndTime").item(0).getTextContent());
                    if(check){
                    	sendGet(0,sGreenFlag,sJobName,sJobInstance);
                    }
				}
			}
		    } catch (Exception e) {
			e.printStackTrace();
		    }
		
	}
		
	private List<String> stat = new ArrayList<String>(); 
	public void setStatus(List<String> stus){
		this.stat = stus;
	}
	public List<String> getResponseStat(){
		return this.stat;
	}
	public void checkStatus(List<String> allStatus,String GreenFlag,String JobName,String JobInstance){
		boolean retval = false;
		try {
			for(String stat : allStatus) {
			  
			  retval = GreenFlag.toUpperCase().contains(stat.trim().toUpperCase());
			  System.out.println(stat + " -> " + GreenFlag.toUpperCase() + "=" + retval );
			  if(!retval){
				  break;
			  }
				  
			}
			
			System.out.println("Check Status:" + retval);
	     	if(retval){
    		System.out.println("Green");
    		setresponseCollector("Status of Job:Green");
    	    }
    	    else{
    		System.out.println("Red");
    		setresponseCollector("Status of Job:Red");
    		RunBatch rb = new RunBatch();
            rb.runBat("RunExecutor.bat",""); //Path of required : "C:\\Users\\IBM_ADMIN\\Desktop\\Macro_C\\"
    	    }
	     	setresponseCollector(sfinalResponse);
	     	ResponseWriter(getresponseCollector().toString().replaceAll(", ", "<br>" ));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Check Status method failed");
			e.printStackTrace();
			}
		
	}
	
	private String sCurrentQueryTime = null;
	private String sStartQueryTime = null;
	private String sEndQueryTime = null;
	
public void setCurrentQueryTime(String StartTime,String EndTime,String sCurrentQueryTime){
		this.sCurrentQueryTime = sCurrentQueryTime;
		this.sStartQueryTime = StartTime;
		this.sEndQueryTime = EndTime;
	}
public String getCurrentQueryTime(String Ref){
		
		if(Ref.equalsIgnoreCase("S")){
			return this.sStartQueryTime;
		}
		else if(Ref.equalsIgnoreCase("E")){
			return this.sEndQueryTime;
		}
		else{
			return this.sCurrentQueryTime;
		}
		
	}
	
//Checks that retry attempts dont exceed the time range of Query Window 
public boolean validateTimeRange(String StartTime,String EndTime,String sQueryTime){
		
		try {
		    String string1 = StartTime;
		    Date time1 = new SimpleDateFormat("HH:mm").parse(string1);
		    Calendar calendar1 = Calendar.getInstance();
		    calendar1.setTime(time1);
		    calendar1.add(Calendar.MINUTE, -1);
		    
		    String string2 = EndTime;
		    Date time2 = new SimpleDateFormat("HH:mm").parse(string2);
		    Calendar calendar2 = Calendar.getInstance();
		    calendar2.setTime(time2);
		    calendar2.add(Calendar.MINUTE, 1);

		    SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm");
		    Date now = new Date();
		    String strTime = sdfTime.format(now);
		    System.out.println(strTime);
		    Date time3 = new SimpleDateFormat("HH:mm").parse(strTime);
		    Calendar calendar3 = Calendar.getInstance();
		    calendar3.setTime(time3);
		   // calendar3.add(Calendar.DATE, 1);

		    Date x = calendar3.getTime();
		    if (x.after(calendar1.getTime()) && x.before(calendar2.getTime())) {
		        //Checks whether the current time is between Start Time and End Time.
		    	System.out.println("validating for Thread Time:" + sQueryTime + " Checking " +  strTime +  " in " + StartTime + " - "  + EndTime + " : " + true);
		        return true;
		    }
		    else{
		    	System.out.println("validating " + sQueryTime + " in " + StartTime + " - "  + EndTime + " : " + false);
		    	 return false;
		    	}
		} catch (ParseException e) {
		    e.printStackTrace();
		    return false;
		}
		
	}

	
	
public boolean validateTime(String StartTime,String EndTime){
		
		try {
		    String string1 = StartTime;
		    Date time1 = new SimpleDateFormat("HH:mm").parse(string1);
		    Calendar calendar1 = Calendar.getInstance();
		    calendar1.setTime(time1);
		    calendar1.add(Calendar.MINUTE, -1);
		    
		    String string2 = EndTime;
		    Date time2 = new SimpleDateFormat("HH:mm").parse(string2);
		    Calendar calendar2 = Calendar.getInstance();
		    calendar2.setTime(time2);
		    calendar2.add(Calendar.MINUTE, 1);

		    SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm");
		    Date now = new Date();
		    String strTime = sdfTime.format(now);
		    System.out.println(strTime);
		    setCurrentQueryTime(StartTime,EndTime,strTime);
		    
		    Date time3 = new SimpleDateFormat("HH:mm").parse(strTime);
		    Calendar calendar3 = Calendar.getInstance();
		    calendar3.setTime(time3);
		   // calendar3.add(Calendar.DATE, 1);

		    Date x = calendar3.getTime();
		    if (x.after(calendar1.getTime()) && x.before(calendar2.getTime())) {
		        //Checks whether the current time is between Start Time and End Time.
		        System.out.println("validateTime:" + true);
		        return true;
		    }
		    else{
		    	System.out.println("validateTime:" + false);
		    	 return false;
		    	}
		} catch (ParseException e) {
		    e.printStackTrace();
		    return false;
		}
		
	}
	
	private List<String> responseCollector = new ArrayList<String>(); 
	public void setresponseCollector(String stus){
		this.getresponseCollector().add(stus);
	}
	public List<String> getresponseCollector(){
		return this.responseCollector;
	}
	
	String sfinalResponse = null;
	
	// HTTP GET request
	
	private void sendGet(int waitCount ,String GreenFlag, String JobName,String JobInstance) {
		List<String> Status = new ArrayList<String>();
       //Test String url = "http://localhost/link2/link2-jobstatus.htm";
		try{
		URL obj = new URL(prepareURL(JobName,JobInstance));
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		Test CookieObj = new Test();
		String sCookie = null;
		Map<String, String> hCookies = CookieObj.getHostCookies(System.getProperty("host"));
		Map<String, String> hCookiesa = CookieObj.getHostCookies("barcapint.com");
		
		//System.out.println("Listing all Cookies:\n" + hCookies.toString() + "\n" + hCookiesa.toString());
		
		// optional default is GET
		con.setRequestMethod("GET");
		if(hCookies.get("WLSG-BarCapINT") != null){
		sCookie = "WLSG-BarCapINT=" + hCookies.get("WLSG-BarCapINT") + "; " + "LLPRODID=" + hCookies.get("LLPRODID") + "; " + "axsidprod=" + hCookiesa.get("axsidprod") + "; " + "BCLPRODINTRANETIC=" + hCookies.get("BCLPRODINTRANETIC") ;//System.getProperty("cookie");
		}
		else{
			sCookie = "WLEU-BarCapINT=" + hCookies.get("WLEU-BarCapINT") + "; " + "LLPRODID=" + hCookies.get("LLPRODID") + "; " + "axsidprod=" + hCookiesa.get("axsidprod") + "; " + "BCLPRODINTRANETIC=" + hCookies.get("BCLPRODINTRANETIC") ;//System.getProperty("cookie");
			}
		System.out.println("Fetching required Cookies:\n" + sCookie);
		//Adding request header
		con.setRequestProperty("User-Agent", USER_AGENT);
        con.setRequestProperty("Cookie", sCookie);
		// Sample Cookie : "WLSG-BarCapINT=TKQrXWDdnnQcyFyqN4mxfVXyKLTtydkF2zzZ2SwLX1c1jXjSpL4n!1242365558!1753811291; LLPRODID=zAoFslUHf3ig0P0O/Als8aqV/M/WlDUZggdA+ORrisI=; axsidprod=AAAAAwABAIDuihnlx%2FNjGnjwUAMXdXDt9VspxkGuWgOfi7fE47bIci5fQNx4aBr%2FIn6llB6pOREt2GoGnZLxXq1za2%2Bw8EvWCyKYg0srvEeLbg5HIFxv5LOV7L%2Bv1NOAs0C0t%2BVpeg6W6QUCZdbrFTcEi4NaxvRseN1eiN9y0Yy5SRHDVSfRCA%3D%3D; BCLPRODINTRANETIC=1473685308910|8914626|Iw43sDzIBPdzUYrXp8QkdJHwfT4=");
        con.setRequestProperty("Connection", "keep-alive");
        con.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
        con.setRequestProperty("Accept-Encoding", "gzip, deflate, sdch");
        con.setRequestProperty("Cache-Control","max-age=0");
		int responseCode = con.getResponseCode();
		System.out.println("\nSending 'GET' request to URL : " + prepareURL(JobName,JobInstance));
		System.out.println("Response Code : " + responseCode);
        if(responseCode == 200){
		BufferedReader in = new BufferedReader(
		        new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		//Generate the response and extract the status
	    if(response.toString().contains("LLErrorMessageText")){
	    	String errorTag = response.toString().split("LLErrorMessageText")[1].split(">")[1].split("</td>")[0];
	    	System.out.println("Invalid Configuration found : " + errorTag + "in AutomationConfig.xml .");
        	ResponseWriter("<html><h1>Unable to fetch response .<br> Reason:Invalid Configuration found : " + errorTag + " in AutomationConfig.xml</h1></BODY></HTML>","Error.html","ErrorMail.bat");
       	    }
	    else{
		String[] tableContent = response.toString().split("<table");
	    String xml = "<table" +  tableContent[5].split("</table>")[0] + "</table>";
	    String[] bgcolor = xml.split("bgcolor");
	    for(int i=1;i<bgcolor.length;i++){
	    	System.out.println(bgcolor[i].substring(8).split(" ")[0]);
	    	Status.add(bgcolor[i].substring(8).split(" ")[0]);
	    }
	    sfinalResponse = "Job Start Time:" + getCurrentQueryTime("S") + "  Job End Time:" + getCurrentQueryTime("E")  + "   Job Run Time:" + getCurrentQueryTime("C") + "<br>" + xml;
	    checkStatus(Status,GreenFlag,JobName,JobInstance);
	    }
        
        }
        else
        {  //ResponseWriter("<HTML><BODY><h1>Error in Connection. Response Code:" + responseCode + "</h1></BODY></HTML>");
        	System.out.println("Error in Response . Response Code:" + responseCode);
        	waitCount++;
			System.out.println("Attempt " + waitCount + " . Retrying after 59 seconds for response");
			 try {
				// System.out.println("in catch");
		         if(validateTimeRange(getCurrentQueryTime("S"),getCurrentQueryTime("E"),getCurrentQueryTime("C")))   {
		        	 System.out.println("Launching Chrome to fetch new session cookies ... ");
		        	 RunBatch launchChromeSession = new RunBatch();
		        	 launchChromeSession.runBat("LaunchSession.bat","");
		        	 Thread.sleep(59000);
		        	sendGet(waitCount,GreenFlag,JobName, JobInstance);
		         }
		         else{
		        	 
		        	System.out.println("Time Elaspsed for the current Job . Response Timeout ");
		        	ResponseWriter("<html><h1>Time Elaspsed for the current Job . Reason:Response Code:" + responseCode + "</h1></BODY></HTML>","Error.html","ErrorMail.bat");
		         }
				 
		        }
		        catch (InterruptedException ie) {
		            // Handle the exception
		        	ie.printStackTrace();
		        }
        
        }

		}catch (Exception ie) {
            // Handle the exception
        	ie.printStackTrace();
        	System.out.println("Error Exception in Connection with Host . Please check the internet connection");
        	waitCount++;
			System.out.println("Attempt " + waitCount + " retrying after 10 seconds for response");
			 try {
				// System.out.println("in catch");
		         if(validateTimeRange(getCurrentQueryTime("S"),getCurrentQueryTime("E"),getCurrentQueryTime("C")))   {
		        	Thread.sleep(10000);
		        	sendGet(waitCount,GreenFlag,JobName, JobInstance);
		         }
		         else{
		        	 
		        System.out.println("Time Elaspsed for the current Job . Response Timeout ");
		        ResponseWriter("<html><h1>Time Elaspsed for the current Job . Reason:Host Unreachable or Internet Connection Down<h1></html>","Error.html","ErrorMail.bat");
		        	
		         }
				 
		        }
		        catch (InterruptedException ief) {
		            // Handle the exception
		        	ief.printStackTrace();
		        }
        }
      
  	}
	
	public void ResponseWriter(String content){
		try {
            //System.out.println(sfinalResponse);
			File file = new File("JobResponse.html");

			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(content);
			bw.close();

			System.out.println("Response written to JobResponse. Invoking Mailing sequence..");
			RunBatch respToExcel = new RunBatch();
			respToExcel.runBat("RunRespMail.bat","");

		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
	public void ResponseWriter(String content,String sFilename,String sBatchName){
		try {
			File file = new File(sFilename);
			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(content);
			bw.close();

			System.out.println("ErrorResponse " + sFilename );
			RunBatch respToExcel = new RunBatch();
			respToExcel.runBat(sBatchName,"");

		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
	}
