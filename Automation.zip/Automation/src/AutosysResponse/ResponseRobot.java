package AutosysResponse;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
//import java.util.ArrayList;
//import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ResponseRobot {

	/**
	 * @param args
	 */
	public void runRobot(){
		try {
			RunBatch launchChromeSession = new RunBatch();
       	    launchChromeSession.runBat("LaunchSession.bat","");
       	    System.out.println("Please wait .... fetching data");
       	    Thread.sleep(45000);
			File fXmlFile = new File("AutomationConfig.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			NodeList nList = doc.getElementsByTagName("Job");
			System.out.println("---------  Verifying Configuration --------");
			System.out.println("\n");
			
			System.out.println("NO.           JOB NAME           JOB INSTANCE   CONFIGURATION STATUS\n");
			System.out.println("===   =========================  ============   ====================\n");

			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);

			//System.out.println("\n JOB NUMBER :" + nNode.getNodeName());
			//System.out.println("\n ***********JOB NUMBER :" + (temp + 1) + "**************");

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;
					//System.out.println("StartTime : " + eElement.getElementsByTagName("StartTime").item(0).getTextContent());
					//System.out.println("EndTime : " + eElement.getElementsByTagName("EndTime").item(0).getTextContent());
					//System.out.println("GreenFlag : " + eElement.getElementsByTagName("GreenFlag").item(0).getTextContent());
					
					String sJobName = eElement.getElementsByTagName("JobName").item(0).getTextContent();
					String sJobInstance = eElement.getElementsByTagName("JobInstance").item(0).getTextContent();
					String sGreenFlag = eElement.getElementsByTagName("GreenFlag").item(0).getTextContent();
					sendGet(0,temp + 1,sGreenFlag,sJobName,sJobInstance);
                    
				}
			}
		    } catch (Exception e) {
			e.printStackTrace();
		    }
		
	}

	private void sendGet(int waitCount ,int jobNumber ,String GreenFlag, String JobName,String JobInstance) {
		//List<String> Status = new ArrayList<String>();
		VerifyResponse vr = new VerifyResponse();
		 //Test String url = "http://localhost/link2/link2-jobstatus.htm";
		try{
		URL obj = new URL(vr.prepareURL(JobName,JobInstance));
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		Test CookieObj = new Test();
		String sCookie = null;
		Map<String, String> hCookies = CookieObj.getHostCookies(System.getProperty("my.barcapint.com"));
		Map<String, String> hCookiesa = CookieObj.getHostCookies("barcapint.com");
		
		//System.out.println("Listing all Cookies:\n" + hCookies.toString() + "\n" + hCookiesa.toString());
		
		// optional default is GET
		con.setRequestMethod("GET");
		if(hCookies.get("WLSG-BarCapINT") != null){
		sCookie = "WLSG-BarCapINT=" + hCookies.get("WLSG-BarCapINT") + "; " + "LLPRODID=" + hCookies.get("LLPRODID") + "; " + "axsidprod=" + hCookiesa.get("axsidprod") + "; " + "BCLPRODINTRANETIC=" + hCookies.get("BCLPRODINTRANETIC") ;//System.getProperty("cookie");
		}
		else{
			sCookie = "WLEU-BarCapINT=" + hCookies.get("WLEU-BarCapINT") + "; " + "LLPRODID=" + hCookies.get("LLPRODID") + "; " + "axsidprod=" + hCookiesa.get("axsidprod") + "; " + "BCLPRODINTRANETIC=" + hCookies.get("BCLPRODINTRANETIC") ;//System.getProperty("cookie");
			}
		//System.out.println("Fetching required Cookies:\n" + sCookie);
		//Adding request header
		con.setRequestProperty("User-Agent", "Mozilla/5.0");
        con.setRequestProperty("Cookie", sCookie);
		// Sample Cookie : "WLSG-BarCapINT=TKQrXWDdnnQcyFyqN4mxfVXyKLTtydkF2zzZ2SwLX1c1jXjSpL4n!1242365558!1753811291; LLPRODID=zAoFslUHf3ig0P0O/Als8aqV/M/WlDUZggdA+ORrisI=; axsidprod=AAAAAwABAIDuihnlx%2FNjGnjwUAMXdXDt9VspxkGuWgOfi7fE47bIci5fQNx4aBr%2FIn6llB6pOREt2GoGnZLxXq1za2%2Bw8EvWCyKYg0srvEeLbg5HIFxv5LOV7L%2Bv1NOAs0C0t%2BVpeg6W6QUCZdbrFTcEi4NaxvRseN1eiN9y0Yy5SRHDVSfRCA%3D%3D; BCLPRODINTRANETIC=1473685308910|8914626|Iw43sDzIBPdzUYrXp8QkdJHwfT4=");
        con.setRequestProperty("Connection", "keep-alive");
        con.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
        con.setRequestProperty("Accept-Encoding", "gzip, deflate, sdch");
        con.setRequestProperty("Cache-Control","max-age=0");
		int responseCode = con.getResponseCode();
		//System.out.println("\nSending 'GET' request to URL : " + vr.prepareURL(JobName,JobInstance));
		//System.out.println("Response Code : " + responseCode);
        if(responseCode == 200){
        	BufferedReader in = new BufferedReader(
    		        new InputStreamReader(con.getInputStream()));
    		String inputLine;
    		StringBuffer response = new StringBuffer();

    		while ((inputLine = in.readLine()) != null) {
    			response.append(inputLine);
    		}
    		in.close();

    		//Generate the response and extract the status
    	    if(response.toString().contains("LLErrorMessageText")){
    	    	String errorTag = response.toString().split("LLErrorMessageText")[1].split(">")[1].split("</td>")[0];
    	    	JobName = JobName + "                              ";
    	    	JobInstance = JobInstance + "      ";
    	    	System.out.println( (jobNumber + "   ").substring(0,3) + "   " + JobName.substring(0, 30) + "  " + JobInstance.substring(0,6) + "  Invalid Configuration found : " + errorTag + "in AutomationConfig.xml .");
            	}
    	    else{
    	    	System.out.println( (jobNumber + "   ").substring(0,3) + "   " + JobName.substring(0, 30) + "  " + JobInstance.substring(0,6) + "  OK");
            	
    	    }
        
        }
        else
        {  //ResponseWriter("<HTML><BODY><h1>Error in Connection. Response Code:" + responseCode + "</h1></BODY></HTML>");
        	System.out.println("Error in Response . Response Code:" + responseCode);
        	        
        }

		}catch (Exception ie) {
            // Handle the exception
        	ie.printStackTrace();
        	System.out.println("Error Exception in Connection with Host . Please check the internet connection");
        	
        }
      
  	}


}
