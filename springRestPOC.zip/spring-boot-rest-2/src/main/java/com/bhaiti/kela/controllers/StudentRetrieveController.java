package com.bhaiti.kela.controllers;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bhaiti.kela.bean.Student;
import com.bhaiti.kela.bean.StudentRegistration;

@Controller
public class StudentRetrieveController {
	
	@RequestMapping(method = RequestMethod.GET, value="/redirect")
	public ResponseEntity<String> handle() {
	    URI location;
	    HttpHeaders responseHeaders = null;
		try {
			location = new URI("/dashboard");
		
	    responseHeaders = new HttpHeaders();
	    responseHeaders.setLocation(location);
	    responseHeaders.set("MyResponseHeader", "MyValue");
	   
	    } catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ResponseEntity<String>(e.getMessage(), responseHeaders, HttpStatus.MOVED_PERMANENTLY);
			 
		}
		
		return new ResponseEntity<String>("Hello World", responseHeaders, HttpStatus.MOVED_PERMANENTLY);
		
	}
	
@RequestMapping(method = RequestMethod.GET, value="/dashboard")
	
	@ResponseBody
	public String getDashboard() {
		return "HomePage";
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/student/allstudent")
	
	@ResponseBody
	public List<Student> getStudent() {
		return StudentRegistration.getInstance().getStudentRecords();
	}

}
