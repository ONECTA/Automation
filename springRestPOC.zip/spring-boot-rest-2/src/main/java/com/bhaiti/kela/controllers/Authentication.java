package com.bhaiti.kela.controllers;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bhaiti.kela.bean.*;

@Controller
public class Authentication {
	
	
	@RequestMapping(value = "/authentication", method = RequestMethod.POST,consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	@ResponseBody
	String auth(@RequestParam Map<String,String> allParams) {
		System.out.println("Parameters are " + allParams.entrySet());
	    return "SAMLResponse is " + allParams.get("SAMLResponse");
	}
	
	@RequestMapping("/hello")
	@ResponseBody
	public ResponseEntity<String> handle() {
	    URI location;
	    HttpHeaders responseHeaders = null;
		try {
			location = new URI("/student/redirected");
		
	    responseHeaders = new HttpHeaders();
	    responseHeaders.setLocation(location);
	    responseHeaders.set("MyResponseHeader", "MyValue");
	   
	    } catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ResponseEntity<String>(e.getMessage(), responseHeaders, HttpStatus.MOVED_PERMANENTLY);
			 
		}
		
		return new ResponseEntity<String>("Hello World", responseHeaders, HttpStatus.MOVED_PERMANENTLY);
		
	}

}
