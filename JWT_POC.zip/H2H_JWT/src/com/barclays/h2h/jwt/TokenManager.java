package com.barclays.h2h.jwt;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.json.JSONObject;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.security.Key;
import io.jsonwebtoken.*;
import java.util.Date;
import java.util.Properties;

import javax.xml.bind.DatatypeConverter;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.Claims;

public class TokenManager {
	 private final Properties properties;
	 
	 TokenManager(){
		 
		  properties = new Properties();
	try {
		properties.load(new FileReader("src/test.properties"));
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 }
	
	//Method to construct a JWT
	private String createJWT(String payload) {
	 
	    //The JWT signature algorithm we will be using to sign the token
	    SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
	 
	    long nowMillis = System.currentTimeMillis();
	    Date now = new Date(nowMillis);
	 
	    //We will sign our JWT with our secret configured in the property file 
	    byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(properties.getProperty("service.jwt.secret"));
	    Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());
	 
	    //Let's set the JWT Claims
	    JwtBuilder builder = Jwts.builder().setPayload(payload).signWith(signingKey, signatureAlgorithm);
	 
	    
	    //Builds the JWT and serializes it to a compact, URL-safe string
	    return builder.compact();
	}
	
	
	//Sample method to validate and read the JWT
	private Claims parseJWT(String jwt) {
	 
	    //This line will throw an exception if it is not a signed JWS (as expected)
	    Claims claims = Jwts.parser()         
	       .setSigningKey(DatatypeConverter.parseBase64Binary(properties.getProperty("service.jwt.secret")))
	       .parseClaimsJws(jwt).getBody();
	    //Return all the claims from Payload
	    return claims;
	}
	public static void main(String[] args) {
		// Add claims to payload
		 JSONObject payloadClaims = new JSONObject();
		 payloadClaims.put("BRID", "G01281786");
		 payloadClaims.put("fullName", "Ashutosh Kushwaha");
		 payloadClaims.put("authenticated", "true");
		 payloadClaims.put("permissions", "H2H_UI_Dashboard");
		    
		TokenManager tm = new TokenManager();
	
		String token = tm.createJWT(payloadClaims.toString());
			System.out.println("JWT=" + token);
			Claims claims =  tm.parseJWT(token);    
		 System.out.println("Claims=" + claims.get("permissions"));
	}

}
